package com.ista.springtboot.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ista.springtboot.Entity.Autor;
import com.ista.springtboot.Repositori.BaseDao;
@Service
public class AutorServiceImpl extends BaseServiceImpl<Autor, Long> implements AutorService {
	@Autowired
	private BaseDao<Autor, Long> autorD;

}
