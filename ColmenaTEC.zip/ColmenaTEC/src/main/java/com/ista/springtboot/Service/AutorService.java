package com.ista.springtboot.Service;

import com.ista.springtboot.Entity.Autor;

public interface AutorService extends BaseService<Autor, Long>{

}
