package com.ista.springtboot.Service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ista.springtboot.Entity.Persona;
import com.ista.springtboot.Repositori.BaseDao;
import com.ista.springtboot.Repositori.PersonaDao;

@Service
public class PersonaServiceImpl extends BaseServiceImpl<Persona, Long> {

	@Autowired
	private PersonaDao personaD;

}
