package com.ista.springtboot.Entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Libros extends Base{
	private String titulo;
	private int fecha;
	private String genero;
	private int paginas;
	@ManyToMany(cascade = CascadeType.REFRESH)
	@JoinColumn(name="libros_autor")
	private List<Autor> autores;
}
