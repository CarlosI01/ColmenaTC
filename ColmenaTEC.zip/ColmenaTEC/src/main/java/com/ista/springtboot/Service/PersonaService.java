package com.ista.springtboot.Service;
import java.util.List;

import com.ista.springtboot.Entity.Persona;
public interface PersonaService extends BaseService<Persona, Long>{
	/*public List<E> findAll() throws Exception;
	public E save (E entity) throws Exception;
	public E findByAll (Long id) throws Exception;
	public E udatep (Long id, E entity) throws Exception;
	public boolean delete (Long id) throws Exception;*/
}
