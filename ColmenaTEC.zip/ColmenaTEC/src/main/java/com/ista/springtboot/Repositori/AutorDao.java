package com.ista.springtboot.Repositori;

import com.ista.springtboot.Entity.Autor;

public interface AutorDao extends BaseDao<Autor, Long>{

}
