package com.ista.springtboot.Repositori;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.NoRepositoryBean;

import com.ista.springtboot.Entity.Base;
@NoRepositoryBean
public interface BaseDao <E extends Base, ID extends Serializable> extends JpaRepository<E, ID>{

}
