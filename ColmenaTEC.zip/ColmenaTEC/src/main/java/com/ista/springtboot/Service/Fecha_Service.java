package com.ista.springtboot.Service;

import com.ista.springtboot.Entity.Fecha_Prueba;

public interface Fecha_Service extends BaseService<Fecha_Prueba, Long>{

}
