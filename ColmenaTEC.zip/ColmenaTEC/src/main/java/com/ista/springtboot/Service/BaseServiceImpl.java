package com.ista.springtboot.Service;
import java.io.Serializable;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import com.ista.springtboot.Entity.Base;
import com.ista.springtboot.Repositori.BaseDao;

public abstract class BaseServiceImpl<E extends Base, ID extends Serializable> implements BaseService<E, ID> {
	
	@Autowired
	private BaseDao<E, ID> baserepository;

	@Override
	@Transactional
	public List<E> findAll() throws Exception {
		try {
			List<E> entities = baserepository.findAll();
			return entities;
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	@Override
	@Transactional
	public E save(E entity) throws Exception {
		try {
			entity = baserepository.save(entity);
			return entity;
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}


	@Override
	@Transactional
	public E findByAll(ID id) throws Exception {
		try {
			Optional<E> optionalP = baserepository.findById(id);
			return optionalP.get();
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	@Override
	@Transactional
	public E udatep(ID id, E entity) throws Exception {
		try {
			Optional<E> option_update = baserepository.findById(id);
			E base = option_update.get();
			base = baserepository.save(entity);
			return base;
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	@Override
	@Transactional
	public boolean delete(ID id) throws Exception {
		try {
			if (baserepository.existsById(id)) {
				baserepository.deleteById(id);
				return true;
			} else {
				throw new Exception();
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

}
