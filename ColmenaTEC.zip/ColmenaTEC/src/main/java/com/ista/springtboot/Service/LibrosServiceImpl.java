package com.ista.springtboot.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ista.springtboot.Entity.Libros;
import com.ista.springtboot.Repositori.LibrosDao;

@Service
public class LibrosServiceImpl extends BaseServiceImpl<Libros, Long> implements LibroService {
	@Autowired
	private LibrosDao libroD;
}
