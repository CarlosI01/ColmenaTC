package com.ista.springtboot.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ista.springtboot.Entity.Fecha_Prueba;
import com.ista.springtboot.Repositori.BaseDao;
import com.ista.springtboot.Repositori.Fecha_Repository;
@Service
public class Fecha_ServiceImpl extends BaseServiceImpl<Fecha_Prueba, Long> implements Fecha_Service{
	@Autowired
	private Fecha_Repository fechaD;
}
