package com.ista.springtboot.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ista.springtboot.Entity.Domicilio;
import com.ista.springtboot.Repositori.DomicilioDao;
@Service
public class DomicilioServiceImpl extends BaseServiceImpl<Domicilio, Long> implements DomicilioService{
	@Autowired
	private DomicilioDao domicilioD;
}
