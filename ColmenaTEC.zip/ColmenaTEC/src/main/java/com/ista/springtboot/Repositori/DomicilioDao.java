package com.ista.springtboot.Repositori;

import com.ista.springtboot.Entity.Domicilio;

public interface DomicilioDao extends BaseDao<Domicilio, Long>{

}
