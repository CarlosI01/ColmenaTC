package com.ista.springtboot.Controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ista.springtboot.Entity.Domicilio;
import com.ista.springtboot.Service.DomicilioServiceImpl;

@RestController
@CrossOrigin(origins ="*")
@RequestMapping(path = "v1/api/domicilio/")
public class DomicilioController extends BaseComtrollerImpl<Domicilio, DomicilioServiceImpl>{

	@Override
	public ResponseEntity<?> save(Domicilio entity) {
		// TODO Auto-generated method stub
		return null;
	}

}
