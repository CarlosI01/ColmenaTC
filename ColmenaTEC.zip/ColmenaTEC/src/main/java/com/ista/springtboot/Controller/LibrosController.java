package com.ista.springtboot.Controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ista.springtboot.Entity.Libros;
import com.ista.springtboot.Service.LibrosServiceImpl;
@RestController
@CrossOrigin(origins ="*")
@RequestMapping(path = "v1/api/libros/")
public class LibrosController extends BaseComtrollerImpl<Libros, LibrosServiceImpl>{

	@Override
	public ResponseEntity<?> save(Libros entity) {
		// TODO Auto-generated method stub
		return null;
	}

}
