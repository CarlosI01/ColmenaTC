package com.ista.springtboot.Entity;


import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="Fechas")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Fecha_Prueba extends Base {
	private  String nombre;
	//@Temporal(TemporalType.TIME)
	/*@JsonFormat(pattern = "yyyy-MM-dd", shape=Shape.STRING)
	@Column(name="Fecha")
	private String Fecha;*/
	//private Date Fecha = new Date(System.currentTimeMillis());
	@Column(name="Fecha")
	private LocalDate localDate = LocalDate.now();

	private int edad;
	
}
