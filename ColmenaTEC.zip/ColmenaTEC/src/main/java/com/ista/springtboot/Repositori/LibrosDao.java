package com.ista.springtboot.Repositori;

import com.ista.springtboot.Entity.Libros;

public interface LibrosDao extends BaseDao<Libros, Long>{

}
