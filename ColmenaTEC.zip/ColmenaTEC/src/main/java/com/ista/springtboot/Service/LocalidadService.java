package com.ista.springtboot.Service;

import com.ista.springtboot.Entity.Localidad;

public interface LocalidadService extends BaseService<Localidad, Long> {

}
