package com.ista.springtboot.Repositori;
import com.ista.springtboot.Entity.Localidad;

public interface LocalidadDao extends BaseDao<Localidad, Long>  {

}
