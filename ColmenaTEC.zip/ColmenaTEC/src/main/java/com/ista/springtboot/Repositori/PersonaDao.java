package com.ista.springtboot.Repositori;

import org.springframework.stereotype.Repository;

import com.ista.springtboot.Entity.Persona;

@Repository
public interface PersonaDao extends BaseDao<Persona, Long>{

}
