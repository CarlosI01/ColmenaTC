package com.ista.springtboot.Controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ista.springtboot.Entity.Fecha_Prueba;
import com.ista.springtboot.Service.Fecha_ServiceImpl;

@RestController
@CrossOrigin(origins ="*")
@RequestMapping(path = "v1/api/fecha/")
public class Fecha_Controller extends BaseComtrollerImpl<Fecha_Prueba, Fecha_ServiceImpl>{

	@Override
	public ResponseEntity<?> save(Fecha_Prueba entity) {
		// TODO Auto-generated method stub
		return null;
	}

}
