package com.ista.springtboot.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.internal.build.AllowPrintStacktrace;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="Autor")
@Getter
@Setter
@AllowPrintStacktrace
@NoArgsConstructor
public class Autor extends Base{
	
	private String nombre;
	private String Apellido;
	@Column(name="biografia", length = 1500)
	private String biografia;

}
