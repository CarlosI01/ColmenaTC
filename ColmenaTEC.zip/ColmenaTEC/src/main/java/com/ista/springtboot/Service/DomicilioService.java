package com.ista.springtboot.Service;

import com.ista.springtboot.Entity.Domicilio;

public interface DomicilioService extends BaseService<Domicilio, Long>{
	
}
