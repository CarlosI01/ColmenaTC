package com.ista.springtboot.Repositori;

import com.ista.springtboot.Entity.Fecha_Prueba;

public interface Fecha_Repository extends BaseDao<Fecha_Prueba, Long>{

}
