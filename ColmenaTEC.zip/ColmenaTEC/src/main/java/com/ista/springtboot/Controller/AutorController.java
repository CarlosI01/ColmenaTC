package com.ista.springtboot.Controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ista.springtboot.Entity.Autor;
import com.ista.springtboot.Service.AutorServiceImpl;

@RestController
@CrossOrigin(origins ="*")
@RequestMapping(path = "v1/api/autor/")
public class AutorController extends BaseComtrollerImpl<Autor, AutorServiceImpl>{

	@Override
	public ResponseEntity<?> save(Autor entity) {
		// TODO Auto-generated method stub
		return null;
	}

}
