package com.ista.springtboot.Controller;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ista.springtboot.Entity.Localidad;
import com.ista.springtboot.Service.LocalidadServiceImpl;
@RestController
@CrossOrigin(origins ="*")
@RequestMapping(path = "v1/api/localidad/")
public class LocalidadController extends BaseComtrollerImpl<Localidad, LocalidadServiceImpl> {

	@Override
	public ResponseEntity<?> save(Localidad entity) {
		// TODO Auto-generated method stub
		return null;
	}

}
