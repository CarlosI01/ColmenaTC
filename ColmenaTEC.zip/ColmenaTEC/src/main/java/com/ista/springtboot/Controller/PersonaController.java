package com.ista.springtboot.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.StreamingHttpOutputMessage.Body;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ista.springtboot.Entity.Persona;
import com.ista.springtboot.Service.BaseServiceImpl;
import com.ista.springtboot.Service.PersonaService;
import com.ista.springtboot.Service.PersonaServiceImpl;
@RestController
@CrossOrigin(origins ="*")
@RequestMapping(path = "v1/api/persona/")
public class PersonaController extends BaseComtrollerImpl<Persona , PersonaServiceImpl> {

	@Override
	public ResponseEntity<?> save(Persona entity) {
		// TODO Auto-generated method stub
		return null;
	}


	/*@Autowired
	private PersonaService personaS;
	
	@GetMapping("persona")
	public ResponseEntity<?> getAll(){
		try {
			return ResponseEntity.status(HttpStatus.OK).body(personaS.findAll());
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("{\"error\" :\"El Andres es Heteroxual y le gusta la pinga de la grande demaciada grande :)}");
		}
	}
	
	@GetMapping("shear/{id}")
	public ResponseEntity<?> getOne(@PathVariable Long id){
		try {
			return ResponseEntity.status(HttpStatus.OK).body(personaS.findByAll(id));
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("{\"error\" :\"El Andres es Heteroxual y le gusta la pinga de la grande demaciada grande :)}");
		}
	}
	@PostMapping("creat")
	public ResponseEntity<?> create(@RequestBody Persona persona){
		try {
			return ResponseEntity.status(HttpStatus.OK).body(personaS.save(persona));
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("{\"error\" :\"El Andres es Heteroxual y le gusta la pinga de la grande demaciada grande :)}");
		}
	}
	@PutMapping("edit/{id}")
	public ResponseEntity<?> update(@PathVariable Long id, @RequestBody Persona persona){
		try {
			return ResponseEntity.status(HttpStatus.OK).body(personaS.udatep(id, persona));
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("{\"error\" :\"El Andres es Heteroxual y le gusta la pinga de la grande demaciada grande :)}");
		}
	}
	
	@DeleteMapping("delete/{id}")
	public ResponseEntity<?> delete(@PathVariable Long id){
		try {
			return ResponseEntity.status(HttpStatus.NO_CONTENT).body(personaS.delete(id));
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("{\"error\" :\"El Andres es Heteroxual y le gusta la pinga de la grande demaciada grande :)}");
		}
	}
*/
}
