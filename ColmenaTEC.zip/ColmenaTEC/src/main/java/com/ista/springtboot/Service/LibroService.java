package com.ista.springtboot.Service;

import com.ista.springtboot.Entity.Libros;

public interface LibroService extends BaseService<Libros, Long>{

}
