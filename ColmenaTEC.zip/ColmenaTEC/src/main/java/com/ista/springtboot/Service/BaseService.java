package com.ista.springtboot.Service;

import java.io.Serializable;
import java.util.List;

import com.ista.springtboot.Entity.Base;

public interface BaseService<E extends Base, ID extends Serializable> {
	public List<E> findAll() throws Exception;
	public E save (E entity) throws Exception;
	public E findByAll (ID id) throws Exception;
	public E udatep (ID id, E entity) throws Exception;
	public boolean delete (ID id) throws Exception;

}
