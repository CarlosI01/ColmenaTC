package com.ista.springtboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ColmenaTecApplicationTests {

	@Test
	void contextLoads() {
	}

}
